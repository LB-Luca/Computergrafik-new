#!/bin/sh

glslc gouraud_shader.vert -o gouraud_vert.spv
glslc gouraud_shader.frag -o gouraud_frag.spv
